import random


def game(comp, you):
    if comp == 'g':
        if you == 'w':
            print('You are win')
        elif you == 's':
            print('Computer win and you loos')
    elif comp == 'w':
        if you == 's':
            print('You are win')
        elif you == 'g':
            print('Computer win and you loos')
    elif comp == 's':
        if you == 'g':
            print('You are win')
        elif you == 'w':
            print('Computer win and you loos')
    elif comp == you:
        print('Game is tie')


print('Please choose any character like:-(g)gun,(w)water,(s)snack?')
you = input('You chooses:')
randomNo = random.randint(1, 3)
if randomNo == 1:
    comp = 'g'
elif randomNo == 2:
    comp = 'w'
elif randomNo == 3:
    comp = 's'
print('Computer chooses:', comp)
game(comp, you)
