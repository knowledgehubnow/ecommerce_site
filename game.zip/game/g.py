def add(a, b):
    c = a + b
    print('Addition of numbers', c)


def sub(a, b):
    c = a - b
    print('Addition of numbers', c)


def multiply(a, b):
    c = a * b
    print('Addition of numbers', c)


def div(a, b):
    c = a/b
    print('Addition of numbers', c)


n1 = int(input('Enter a number:'))
n2 = int(input('Enter a number:'))
op = input('Enter a operator:')
if op == '+':
    add(n1, n2)
elif op == '-':
    sub(n1, n2)
elif op == '*':
    multiply(n1, n2)
elif op == '/':
    div(n1, n2)
else:
    print('Enter a valid operator')
